# Kinetic Portfolio

A single-page portfolio site built with React and React-Bootstrap. High-contrast, acid yellow on near-black (or near-white in light mode), oversized uppercase type, hard color-flip hovers, a marquee that never stops. Loud on purpose.

## Why it looks like this

This started out as a terminal-themed site, dark green on black, monospace everything. It got swapped out for something louder: massive Space Grotesk headlines, cards that flood with acid yellow on hover, a ticker that scrolls forever. Less "hacking into a mainframe," more "poster ripped off a wall and animated." The scale difference between a section heading and body text is deliberately extreme, that's the whole point of the style, not an accident.

## Running it

```
npm install
npm run dev
```

Production build:

```
npm run build
```

Output lands in `dist/`.

## What's under the hood

- React 19 + Vite
- Stock Bootstrap CSS (`bootstrap/dist/css/bootstrap.min.css`), no Sass, no build-time variable overrides. Every color runs through CSS custom properties in `src/styles/theme.css` instead, which is what lets the light/dark toggle flip everything instantly
- lucide-react for most icons, bootstrap-icons fills in for GitHub, LinkedIn, and a couple of filetype icons lucide doesn't ship
- react-lazy-load-image-component for the Work section thumbnails
- lenis for smooth scrolling


## Light and dark mode

Toggle button lives in the header, sun and moon icon depending on the current mode. First visit checks `prefers-color-scheme` for a default, after that it remembers whatever you picked in `localStorage`. Every themeable color is a CSS custom property (`--color-background`, `--color-text`, `--color-accent`, and so on) defined twice in `src/styles/theme.css`, once under `:root` for dark, once under `:root[data-theme='light']`. The toggle just flips that attribute on `<html>`, nothing re-renders or recompiles.


## Folder structure

```
src/
  components/
    Header/Header.jsx
    TechStackSlider/TechStackSlider.jsx
    Work/Work.jsx
    Work/ProjectCard.jsx
    Contact/Contact.jsx
    Footer/Footer.jsx
    common/
      SectionTitle.jsx
      MarqueeStrip.jsx
      TechIcon.jsx
  context/
    ThemeContext.jsx
    LenisContext.jsx
  data/
    techStack.jsx
    workItems.jsx
  styles/
    theme.css
  utils/
    chunkArray.jsx
  App.jsx
  main.jsx
```



## Screenshots

The six images below are stand-ins, "SCREENSHOT PENDING" stamped right on them, not the real site. Run the dev server, grab actual captures, and overwrite the files in `/screenshots` using the same names so this table updates on its own.

| | |
|---|---|
| ![Header and nav](screenshots/01-header-nav.svg) **Header / Nav** | ![Tech stack slider](screenshots/02-tech-stack-slider.svg) **Tech Stack Slider** |
| ![Work grid](screenshots/03-work-section.svg) **Work Grid** | ![Contact form](screenshots/04-contact-form.svg) **Contact Form** |
| ![Footer](screenshots/05-footer.svg) **Footer** | ![Mobile view](screenshots/06-mobile-view.svg) **Mobile View** |

## Walkthrough video


[Watch the walkthrough](#)
